from PIL import Image, ImageDraw, ImageFont
import os

print("="*70)
print("MEJORANDO TUS GRÁFICAS ORIGINALES DE SIMULINK")
print("="*70)

# Función para añadir texto profesional a las imágenes
def mejorar_grafica(input_path, output_path, titulo, xlabel, ylabel):
    """
    Añade título y etiquetas de ejes a una gráfica existente
    """
    try:
        # Abrir la imagen original
        img = Image.open(input_path)
        width, height = img.size
        
        # Crear una nueva imagen más grande para añadir márgenes
        margen_superior = 80
        margen_inferior = 60
        margen_izquierdo = 100
        margen_derecho = 40
        
        new_width = width + margen_izquierdo + margen_derecho
        new_height = height + margen_superior + margen_inferior
        
        # Crear imagen nueva con fondo negro
        new_img = Image.new('RGB', (new_width, new_height), color='#1C1C1C')
        
        # Pegar la imagen original en el centro
        new_img.paste(img, (margen_izquierdo, margen_superior))
        
        # Crear objeto para dibujar
        draw = ImageDraw.Draw(new_img)
        
        # Intentar usar una fuente bonita, si no está disponible usar la predeterminada
        try:
            font_titulo = ImageFont.truetype("arial.ttf", 24)
            font_ejes = ImageFont.truetype("arial.ttf", 18)
        except:
            try:
                font_titulo = ImageFont.truetype("Arial.ttf", 24)
                font_ejes = ImageFont.truetype("Arial.ttf", 18)
            except:
                font_titulo = ImageFont.load_default()
                font_ejes = ImageFont.load_default()
        
        # Añadir título (centrado, arriba)
        titulo_bbox = draw.textbbox((0, 0), titulo, font=font_titulo)
        titulo_width = titulo_bbox[2] - titulo_bbox[0]
        titulo_x = (new_width - titulo_width) // 2
        draw.text((titulo_x, 25), titulo, fill='white', font=font_titulo)
        
        # Añadir etiqueta del eje X (centrado, abajo)
        xlabel_bbox = draw.textbbox((0, 0), xlabel, font=font_ejes)
        xlabel_width = xlabel_bbox[2] - xlabel_bbox[0]
        xlabel_x = (new_width - xlabel_width) // 2
        draw.text((xlabel_x, new_height - 35), xlabel, fill='white', font=font_ejes)
        
        # Añadir etiqueta del eje Y (rotada, izquierda)
        # Como PIL no rota texto fácilmente, lo ponemos vertical
        ylabel_x = 15
        ylabel_y = (new_height - 100) // 2
        
        # Crear imagen temporal para el texto rotado
        temp_img = Image.new('RGBA', (200, 50), color=(0, 0, 0, 0))
        temp_draw = ImageDraw.Draw(temp_img)
        temp_draw.text((10, 10), ylabel, fill='white', font=font_ejes)
        temp_img_rotated = temp_img.rotate(90, expand=True)
        
        # Pegar el texto rotado
        new_img.paste(temp_img_rotated, (ylabel_x, ylabel_y), temp_img_rotated)
        
        # Guardar la imagen mejorada
        new_img.save(output_path, quality=95)
        print(f"✓ {output_path} creado exitosamente")
        return True
        
    except Exception as e:
        print(f"✗ Error procesando {input_path}: {str(e)}")
        return False

# ============================================================================
# MEJORAR LAS 3 IMÁGENES ORIGINALES
# ============================================================================

print("\n📊 IMPORTANTE: Guarda tus 3 capturas de Simulink como:")
print("   • scope_corriente_voltaje.png  (la imagen con ambas gráficas)")
print("   • scope_corriente.png          (solo corriente)")
print("   • scope_voltaje.png            (solo voltaje)")
print("\nO modifica los nombres en este script según tus archivos.\n")

# Imagen 1: Corriente y Voltaje juntos
if os.path.exists('scope_corriente_voltaje.png'):
    print("[1/3] Mejorando: scope_corriente_voltaje.png")
    mejorar_grafica(
        'scope_corriente_voltaje.png',
        'corriente_voltaje_mejorada.png',
        'Corriente y Voltaje - Circuito RLC (R=200Ω, L=10mH, C=100µF)',
        'Tiempo (s)',
        'Amplitud'
    )
else:
    print("[1/3] ⚠ No se encuentra 'scope_corriente_voltaje.png'")

# Imagen 2: Solo corriente
if os.path.exists('scope_corriente.png'):
    print("\n[2/3] Mejorando: scope_corriente.png")
    mejorar_grafica(
        'scope_corriente.png',
        'corriente_bobina_scope.png',
        'Corriente en la Bobina - Circuito RLC Críticamente Amortiguado',
        'Tiempo (s)',
        'Corriente (A)'
    )
else:
    print("\n[2/3] ⚠ No se encuentra 'scope_corriente.png'")

# Imagen 3: Solo voltaje
if os.path.exists('scope_voltaje.png'):
    print("\n[3/3] Mejorando: scope_voltaje.png")
    mejorar_grafica(
        'scope_voltaje.png',
        'voltaje_condensador_scope.png',
        'Voltaje del Condensador - Circuito RLC Críticamente Amortiguado',
        'Tiempo (s)',
        'Voltaje (V)'
    )
else:
    print("\n[3/3] ⚠ No se encuentra 'scope_voltaje.png'")

print("\n" + "="*70)
print("✓ PROCESO COMPLETADO")
print("="*70)

# Verificar qué archivos se crearon
archivos_creados = []
archivos_esperados = [
    'corriente_voltaje_mejorada.png',
    'corriente_bobina_scope.png',
    'voltaje_condensador_scope.png'
]

for archivo in archivos_esperados:
    if os.path.exists(archivo):
        archivos_creados.append(archivo)

if archivos_creados:
    print("\n📁 Archivos creados:")
    for archivo in archivos_creados:
        print(f"  ✓ {archivo}")
    
    print("\n📝 Actualiza el LaTeX para usar estas imágenes:")
    print("  • corriente_voltaje_mejorada.png")
    print("  • corriente_bobina_scope.png")
    print("  • voltaje_condensador_scope.png")
else:
    print("\n⚠ No se creó ningún archivo.")
    print("\n🔧 SOLUCIÓN:")
    print("1. Guarda las 3 capturas de Simulink que me enviaste como:")
    print("   - scope_corriente_voltaje.png")
    print("   - scope_corriente.png")
    print("   - scope_voltaje.png")
    print("\n2. Colócalas en la misma carpeta que este script")
    print("\n3. Ejecuta de nuevo: python mejorar_imagenes_originales.py")

print("="*70)