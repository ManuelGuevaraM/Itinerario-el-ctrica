clear; clc; close all;

% Parámetros
fs = 10000;              % Frecuencia de muestreo [Hz]
t = 0:1/fs:0.1;          % 100 ms
f = 50;                  % Frecuencia de la señal [Hz]

% Señal base
signal = 230 * sqrt(2) * sin(2*pi*f*t);

% Introducimos una caída de tensión simulada
signal(200:400) = signal(200:400) * 0.5; % caída del 50%

% Cálculo RMS con ventana de 20 ms
window_ms = 20;
[rms_vals, t_rms] = rms_ventanas(signal, fs, window_ms);

% Gráficas
figure;
subplot(2,1,1);
plot(t, signal);
title('Señal de tensión');
xlabel('Tiempo [s]');
ylabel('Amplitud [V]');
grid on;

subplot(2,1,2);
plot(t_rms, rms_vals, 'r');
title(['Valor RMS con ventana de ', num2str(window_ms), ' ms']);
xlabel('Tiempo [s]');
ylabel('RMS [V]');
grid on;
