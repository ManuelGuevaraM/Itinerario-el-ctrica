function [f, mag] = analisis_fft(signal, fs)
% ------------------------------------------------------------
% Calcula el espectro de frecuencias de una señal usando la FFT
%
% Entradas:
%   signal -> señal temporal
%   fs     -> frecuencia de muestreo [Hz]
%
% Salidas:
%   f      -> vector de frecuencias [Hz]
%   mag    -> magnitud espectral normalizada
%
% ------------------------------------------------------------

N = length(signal);                % número de muestras
Y = fft(signal);                   % FFT de la señal
P2 = abs(Y / N);                   % espectro bilateral normalizado
P1 = P2(1:N/2+1);                  % solo frecuencias positivas
P1(2:end-1) = 2 * P1(2:end-1);     % multiplicar por 2 las intermedias

f = fs * (0:(N/2)) / N;            % vector de frecuencias
mag = P1;                          % magnitudes normalizadas
end
