function [rms_values, t_rms] = rms_ventanas(signal, fs, window_ms)
% ------------------------------------------------------------
% Calcula el valor RMS de una señal en ventanas deslizantes
%
% Entradas:
%   signal      -> vector con la señal de entrada
%   fs          -> frecuencia de muestreo [Hz]
%   window_ms   -> tamaño de la ventana [ms]
%
% Salidas:
%   rms_values  -> vector con los valores RMS calculados
%   t_rms       -> vector de tiempos correspondiente [s]
%
% Ejemplo:
%   [rms_vals, t_vals] = rms_ventanas(signal, 10000, 20);
% ------------------------------------------------------------

N = length(signal);
window_samples = round(window_ms * fs / 1000); % convertir ms a muestras
rms_values = zeros(1, N - window_samples + 1);

for i = 1:(N - window_samples + 1)
    window_data = signal(i:i + window_samples - 1);
    rms_values(i) = sqrt(mean(window_data.^2));
end

t_rms = (0:length(rms_values)-1) / fs; % vector de tiempos
end
