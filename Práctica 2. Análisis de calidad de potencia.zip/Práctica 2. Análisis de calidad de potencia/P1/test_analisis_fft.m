clear; clc; close all;

%% Parámetros de la señal
fs = 2000;          % Frecuencia de muestreo [Hz]
t = 0:1/fs:1;       % 1 segundo de duración
f_signal = 50;      % Frecuencia de la señal [Hz]
A = 325;            % Amplitud pico [V]

%% Señal sinusoidal pura
signal = A * sin(2*pi*f_signal*t);

%% Calcular FFT
[freqs, mag] = analisis_fft(signal, fs);

%% Visualización
figure;
stem(freqs, mag, 'filled');
xlim([0 500]);
xlabel('Frecuencia [Hz]');
ylabel('Magnitud normalizada');
title('Espectro de amplitud - Señal sinusoidal de 50 Hz');
grid on;

saveas(gcf, 'espectro_fft.png');

%% Verificación
[~, idx_peak] = max(mag);
fprintf('\nPico máximo detectado en %.1f Hz\n', freqs(idx_peak));
