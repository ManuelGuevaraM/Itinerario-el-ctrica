%% ========================================================================
%  EJERCICIO 1.2: DETECCIÓN DE CRUCES POR CERO
%  Procesamiento Digital de Señales
%% ========================================================================

clear all;
close all;
clc;

fprintf('========================================\n');
fprintf('  EJERCICIO 1.2: CRUCES POR CERO\n');
fprintf('========================================\n\n');

%% 1. PARÁMETROS DE LA SEÑAL DE PRUEBA
% Señal sinusoidal para probar la función
f_real = 50;         % Frecuencia real de la señal (Hz)
A = 10;              % Amplitud de la señal
fs = 1000;           % Frecuencia de muestreo (Hz)
duracion = 0.2;      % Duración: 200 ms para ver varios ciclos

fprintf('PARÁMETROS DE LA SEÑAL DE PRUEBA:\n');
fprintf('  - Frecuencia real: %d Hz\n', f_real);
fprintf('  - Amplitud: %d\n', A);
fprintf('  - Frecuencia de muestreo: %d Hz\n', fs);
fprintf('  - Duración: %.0f ms\n\n', duracion*1000);

%% 2. GENERACIÓN DE LA SEÑAL
% Vector de tiempo
t = 0:1/fs:duracion-1/fs;

% Señal sinusoidal
senal = A * sin(2*pi*f_real*t);

N_muestras = length(senal);
N_ciclos = f_real * duracion;

fprintf('INFORMACIÓN DE LA SEÑAL:\n');
fprintf('  - Número de muestras: %d\n', N_muestras);
fprintf('  - Número de ciclos: %.0f\n\n', N_ciclos);

%% 3. DETECCIÓN DE CRUCES POR CERO
[indices_cruces, frecuencia_detectada] = detectarCrucesCero(senal, fs);

% Obtener los tiempos de los cruces
tiempos_cruces = t(indices_cruces);

% Número de cruces detectados
N_cruces = length(indices_cruces);

fprintf('========================================\n');
fprintf('            RESULTADOS\n');
fprintf('========================================\n\n');

fprintf('DETECCIÓN DE CRUCES POR CERO:\n');
fprintf('  - Cruces detectados: %d\n', N_cruces);
fprintf('  - Cruces esperados: %.0f (2 por ciclo)\n\n', N_ciclos * 2);

%% 4. CÁLCULO DE LA FRECUENCIA
fprintf('ANÁLISIS DE FRECUENCIA:\n');
fprintf('  - Frecuencia real: %.4f Hz\n', f_real);
fprintf('  - Frecuencia detectada: %.4f Hz\n', frecuencia_detectada);

% Cálculo del error
error_absoluto = abs(frecuencia_detectada - f_real);
error_porcentual = (error_absoluto / f_real) * 100;

fprintf('  - Error absoluto: %.4f Hz\n', error_absoluto);
fprintf('  - Error porcentual: %.4f %%\n\n', error_porcentual);

%% 5. INFORMACIÓN DE TIEMPOS ENTRE CRUCES
if N_cruces >= 2
    diferencias_tiempo = diff(tiempos_cruces) * 1000; % en ms
    tiempo_promedio = mean(diferencias_tiempo);
    
    fprintf('TIEMPOS ENTRE CRUCES CONSECUTIVOS:\n');
    fprintf('  - Tiempo promedio: %.4f ms\n', tiempo_promedio);
    fprintf('  - Tiempo mínimo: %.4f ms\n', min(diferencias_tiempo));
    fprintf('  - Tiempo máximo: %.4f ms\n', max(diferencias_tiempo));
    fprintf('  - Desviación estándar: %.6f ms\n\n', std(diferencias_tiempo));
end

%% 6. VISUALIZACIÓN COMPLETA
figure('Name', 'Detección de Cruces por Cero', 'Position', [50, 50, 1400, 800]);

% Subplot 1: Señal temporal con cruces marcados
subplot(3,1,1);
plot(t*1000, senal, 'b-', 'LineWidth', 1.5);
hold on;

% Marcar los puntos de cruce por cero con círculos rojos
plot(tiempos_cruces*1000, senal(indices_cruces), 'ro', ...
    'MarkerSize', 8, 'MarkerFaceColor', 'r', 'LineWidth', 2);

% Línea de referencia en cero
yline(0, 'k--', 'LineWidth', 1);

grid on;
xlabel('Tiempo (ms)', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Amplitud', 'FontSize', 11, 'FontWeight', 'bold');
title('Señal Temporal con Cruces por Cero Detectados', ...
    'FontSize', 13, 'FontWeight', 'bold');

% Añadir texto con información
text_str = sprintf('Frecuencia detectada: %.2f Hz\nCruces detectados: %d', ...
    frecuencia_detectada, N_cruces);
text(0.98, 0.95, text_str, 'Units', 'normalized', ...
    'VerticalAlignment', 'top', 'HorizontalAlignment', 'right', ...
    'BackgroundColor', 'white', 'EdgeColor', 'black', ...
    'FontSize', 10, 'FontWeight', 'bold');

% Leyenda
legend('Señal', 'Cruces por Cero', 'Location', 'southeast');
hold off;

% Subplot 2: Zoom en los primeros 3 ciclos
subplot(3,1,2);
t_zoom = 3/f_real;
idx_zoom = t <= t_zoom;
plot(t(idx_zoom)*1000, senal(idx_zoom), 'b-', 'LineWidth', 2);
hold on;

% Cruces en el rango del zoom
idx_cruces_zoom = tiempos_cruces <= t_zoom;
plot(tiempos_cruces(idx_cruces_zoom)*1000, ...
    senal(indices_cruces(idx_cruces_zoom)), 'ro', ...
    'MarkerSize', 10, 'MarkerFaceColor', 'r', 'LineWidth', 2);

% Numerar los cruces
for i = 1:sum(idx_cruces_zoom)
    text(tiempos_cruces(i)*1000, senal(indices_cruces(i)) + 1, ...
        sprintf('%d', i), 'FontSize', 9, 'FontWeight', 'bold', ...
        'HorizontalAlignment', 'center', 'Color', 'red');
end

yline(0, 'k--', 'LineWidth', 1);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Amplitud', 'FontSize', 11, 'FontWeight', 'bold');
title(sprintf('Detalle: Primeros 3 Ciclos (%.1f ms)', t_zoom*1000), ...
    'FontSize', 13, 'FontWeight', 'bold');
legend('Señal', 'Cruces por Cero', 'Location', 'northeast');
hold off;

% Subplot 3: Tiempos entre cruces consecutivos
subplot(3,1,3);
if N_cruces >= 2
    diferencias_ms = diff(tiempos_cruces) * 1000;
    tiempo_teorico = 1000/(2*f_real); % medio período en ms
    
    bar(1:length(diferencias_ms), diferencias_ms, 'FaceColor', [0.2 0.6 0.8]);
    hold on;
    yline(tiempo_teorico, 'r--', sprintf('Teórico = %.2f ms', tiempo_teorico), ...
        'LineWidth', 2, 'FontSize', 10, 'FontWeight', 'bold');
    hold off;
    
    grid on;
    xlabel('Número de Intervalo', 'FontSize', 11, 'FontWeight', 'bold');
    ylabel('Tiempo (ms)', 'FontSize', 11, 'FontWeight', 'bold');
    title('Tiempos entre Cruces Consecutivos (Medio Período)', ...
        'FontSize', 13, 'FontWeight', 'bold');
    
    % Añadir información estadística
    ylim_actual = ylim;
    text_stats = sprintf('Media: %.3f ms\nStd: %.4f ms', ...
        mean(diferencias_ms), std(diferencias_ms));
    text(0.98, 0.95, text_stats, 'Units', 'normalized', ...
        'VerticalAlignment', 'top', 'HorizontalAlignment', 'right', ...
        'BackgroundColor', 'white', 'EdgeColor', 'black', ...
        'FontSize', 10);
end

%% 7. FIGURA ADICIONAL: Análisis del método sign()
figure('Name', 'Análisis del Método de Detección', 'Position', [100, 100, 1400, 700]);

% Subplot 1: Señal original
subplot(3,1,1);
plot(t*1000, senal, 'b-', 'LineWidth', 1.5);
grid on;
yline(0, 'k--', 'LineWidth', 1);
xlabel('Tiempo (ms)', 'FontSize', 10, 'FontWeight', 'bold');
ylabel('Amplitud', 'FontSize', 10, 'FontWeight', 'bold');
title('a) Señal Original', 'FontSize', 12, 'FontWeight', 'bold');
xlim([0 t_zoom*1000]);

% Subplot 2: Función sign()
subplot(3,1,2);
signos = sign(senal);
% Manejar ceros
for i = 2:length(signos)
    if signos(i) == 0
        signos(i) = signos(i-1);
    end
end

stairs(t*1000, signos, 'r-', 'LineWidth', 2);
grid on;
ylim([-1.5 1.5]);
xlabel('Tiempo (ms)', 'FontSize', 10, 'FontWeight', 'bold');
ylabel('sign(señal)', 'FontSize', 10, 'FontWeight', 'bold');
title('b) Aplicación de sign() - Detecta Signo de la Señal', ...
    'FontSize', 12, 'FontWeight', 'bold');
xlim([0 t_zoom*1000]);

% Subplot 3: Diferencia (cambios de signo)
subplot(3,1,3);
cambios = diff(signos);
stem(t(1:end-1)*1000, cambios, 'filled', 'MarkerSize', 4);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 10, 'FontWeight', 'bold');
ylabel('diff(sign)', 'FontSize', 10, 'FontWeight', 'bold');
title('c) Diferencias - Identifica Cruces por Cero (valores ≠ 0)', ...
    'FontSize', 12, 'FontWeight', 'bold');
xlim([0 t_zoom*1000]);

%% 8. TABLA RESUMEN DE CRUCES
fprintf('========================================\n');
fprintf('     TABLA DE CRUCES DETECTADOS\n');
fprintf('========================================\n\n');
fprintf('  N°  |  Tiempo (ms)  |  Índice  \n');
fprintf('------|---------------|----------\n');
for i = 1:min(10, N_cruces) % Mostrar primeros 10
    fprintf(' %3d  |    %7.3f    |  %5d\n', ...
        i, tiempos_cruces(i)*1000, indices_cruces(i));
end
if N_cruces > 10
    fprintf(' ...  |      ...      |   ...\n');
    fprintf(' %3d  |    %7.3f    |  %5d\n', ...
        N_cruces, tiempos_cruces(end)*1000, indices_cruces(end));
end
fprintf('\n');

%% 9. VERIFICACIÓN DE RESULTADOS
fprintf('========================================\n');
fprintf('          VERIFICACIÓN\n');
fprintf('========================================\n\n');

% Verificar que el número de cruces es correcto (2 por ciclo)
cruces_esperados = N_ciclos * 2;
if abs(N_cruces - cruces_esperados) <= 2 % tolerancia de ±2 cruces
    fprintf('✓ Número de cruces: CORRECTO\n');
    fprintf('  Se detectaron %d cruces (esperados ≈ %.0f)\n\n', ...
        N_cruces, cruces_esperados);
else
    fprintf('✗ Número de cruces: VERIFICAR\n');
    fprintf('  Detectados: %d, Esperados: %.0f\n\n', N_cruces, cruces_esperados);
end

% Verificar precisión de la frecuencia
if error_porcentual < 1
    fprintf('✓ Frecuencia detectada: EXCELENTE\n');
    fprintf('  Error: %.4f%% (< 1%%)\n\n', error_porcentual);
elseif error_porcentual < 5
    fprintf('✓ Frecuencia detectada: BUENA\n');
    fprintf('  Error: %.4f%% (< 5%%)\n\n', error_porcentual);
else
    fprintf('⚠ Frecuencia detectada: REVISAR\n');
    fprintf('  Error: %.4f%% (≥ 5%%)\n\n', error_porcentual);
end

%% 10. RESUMEN FINAL
fprintf('========================================\n');
fprintf('         RESUMEN EJECUTIVO\n');
fprintf('========================================\n\n');
fprintf('La función detectarCrucesCero() identifica correctamente\n');
fprintf('los puntos donde la señal cruza por cero.\n\n');
fprintf('Resultados:\n');
fprintf('  • Frecuencia detectada: %.4f Hz\n', frecuencia_detectada);
fprintf('  • Error: %.4f%% respecto a %.0f Hz\n', error_porcentual, f_real);
fprintf('  • Cruces detectados: %d\n\n', N_cruces);
fprintf('Programa finalizado.\n');
fprintf('========================================\n');