%% ========================================================================
%  EJERCICIO 1.1: CÁLCULO DEL VALOR RMS
%  Procesamiento Digital de Señales
%% ========================================================================

%% FUNCIÓN: calcularRMS
% Guardar esta función en un archivo separado llamado: calcularRMS.m
% -------------------------------------------------------------------------
% function valor_rms = calcularRMS(senal)
%     % Calcula el valor RMS de una señal discreta
%     % 
%     % Entrada: 
%     %   senal - vector con los valores de la señal
%     % 
%     % Salida: 
%     %   valor_rms - valor RMS calculado
%     
%     % Número de muestras
%     N = length(senal);
%     
%     % Cálculo del valor RMS usando la fórmula
%     % V_RMS = sqrt(1/N * sum(v_i^2))
%     valor_rms = sqrt((1/N) * sum(senal.^2));
% end
% -------------------------------------------------------------------------

%% SCRIPT PRINCIPAL
% Guardar como: ejercicio_1_1_RMS.m

clear all;
close all;
clc;

fprintf('========================================\n');
fprintf('  EJERCICIO 1.1: CÁLCULO DEL VALOR RMS\n');
fprintf('========================================\n\n');

%% 1. PARÁMETROS DE LA SEÑAL
f = 50;              % Frecuencia de la señal (Hz)
Vp = 325;            % Voltaje pico (V)
fs = 1000;           % Frecuencia de muestreo (Hz)
duracion = 0.1;      % Duración (segundos) = 100 ms
Vteor = 230;         % Valor teórico RMS esperado (V)

fprintf('PARÁMETROS DE LA SEÑAL:\n');
fprintf('  - Frecuencia: %d Hz\n', f);
fprintf('  - Voltaje pico: %d V\n', Vp);
fprintf('  - Frecuencia de muestreo: %d Hz\n', fs);
fprintf('  - Duración: %.1f ms\n', duracion*1000);
fprintf('  - Valor esperado: %d V\n\n', Vteor);

%% 2. GENERACIÓN DE LA SEÑAL SINUSOIDAL
% Vector de tiempo
t = 0:1/fs:duracion-1/fs;

% Señal sinusoidal: v(t) = Vp * sin(2*pi*f*t)
senal = Vp * sin(2*pi*f*t);

% Información sobre las muestras
N_muestras = length(senal);
fprintf('INFORMACIÓN DE MUESTREO:\n');
fprintf('  - Número de muestras: %d\n', N_muestras);
fprintf('  - Número de ciclos: %.1f\n\n', f*duracion);

%% 3. CÁLCULO DEL VALOR RMS
% Usando la función implementada
V_rms_calculado = calcularRMS(senal);

% Cálculo del valor RMS teórico para una sinusoidal
V_rms_teorico = Vp / sqrt(2);

%% 4. CÁLCULO DE ERRORES
% Error respecto al valor esperado
error_absoluto = abs(V_rms_calculado - Vteor);
error_porcentual = (error_absoluto / Vteor) * 100;

% Error respecto al valor teórico
error_abs_teorico = abs(V_rms_calculado - V_rms_teorico);
error_porc_teorico = (error_abs_teorico / V_rms_teorico) * 100;

%% 5. MOSTRAR RESULTADOS
fprintf('========================================\n');
fprintf('            RESULTADOS\n');
fprintf('========================================\n\n');

fprintf('VALORES CALCULADOS:\n');
fprintf('  - Valor RMS calculado:    %.4f V\n', V_rms_calculado);
fprintf('  - Valor RMS teórico:      %.4f V\n', V_rms_teorico);
fprintf('  - Valor esperado:         %.4f V\n\n', Vteor);

fprintf('ANÁLISIS DE ERROR:\n');
fprintf('  Respecto al valor esperado (230 V):\n');
fprintf('    • Error absoluto:       %.4f V\n', error_absoluto);
fprintf('    • Error porcentual:     %.4f %%\n\n', error_porcentual);

fprintf('  Respecto al valor teórico:\n');
fprintf('    • Error absoluto:       %.6f V\n', error_abs_teorico);
fprintf('    • Error porcentual:     %.6f %%\n\n', error_porc_teorico);

%% 6. VERIFICACIÓN DEL CRITERIO
fprintf('========================================\n');
fprintf('          VERIFICACIÓN\n');
fprintf('========================================\n\n');

if error_porcentual < 1
    fprintf('✓ RESULTADO: EXITOSO\n');
    fprintf('  El error (%.4f%%) es MENOR al 1%% requerido\n\n', error_porcentual);
else
    fprintf('✗ RESULTADO: NO CUMPLE\n');
    fprintf('  El error (%.4f%%) es MAYOR o IGUAL al 1%% requerido\n\n', error_porcentual);
end

%% 7. VISUALIZACIÓN DE LA SEÑAL
figure('Name', 'Señal Sinusoidal de Prueba', 'Position', [100, 100, 1000, 600]);

% Subplot 1: Señal completa
subplot(2,1,1);
plot(t*1000, senal, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 11);
ylabel('Voltaje (V)', 'FontSize', 11);
title(sprintf('Señal Sinusoidal - %d Hz, %d V pico (Duración completa: %.1f ms)', ...
    f, Vp, duracion*1000), 'FontSize', 12, 'FontWeight', 'bold');
ylim([-400 400]);
xlim([0 duracion*1000]);

% Líneas de referencia
hold on;
yline(V_rms_calculado, 'r--', sprintf('RMS = %.2f V', V_rms_calculado), ...
    'LineWidth', 1.5, 'LabelHorizontalAlignment', 'left');
yline(-V_rms_calculado, 'r--', 'LineWidth', 1.5);
yline(Vp, 'g--', sprintf('V_{pico} = %d V', Vp), ...
    'LineWidth', 1, 'LabelHorizontalAlignment', 'left', 'Alpha', 0.5);
yline(-Vp, 'g--', 'LineWidth', 1, 'Alpha', 0.5);
hold off;

% Subplot 2: Zoom en los primeros 3 ciclos
subplot(2,1,2);
t_zoom = 3/f; % Mostrar 3 ciclos
idx_zoom = t <= t_zoom;
plot(t(idx_zoom)*1000, senal(idx_zoom), 'b-', 'LineWidth', 2);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 11);
ylabel('Voltaje (V)', 'FontSize', 11);
title(sprintf('Detalle: Primeros 3 ciclos (%.1f ms)', t_zoom*1000), ...
    'FontSize', 12, 'FontWeight', 'bold');
ylim([-400 400]);
xlim([0 t_zoom*1000]);

% Líneas de referencia en zoom
hold on;
yline(V_rms_calculado, 'r--', 'RMS', 'LineWidth', 1.5);
yline(-V_rms_calculado, 'r--', 'LineWidth', 1.5);
hold off;

%% 8. GRÁFICO ADICIONAL: Señal al cuadrado
figure('Name', 'Análisis del Cálculo RMS', 'Position', [150, 150, 1000, 500]);

subplot(2,1,1);
plot(t*1000, senal.^2, 'm-', 'LineWidth', 1.5);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 11);
ylabel('Voltaje^2 (V^2)', 'FontSize', 11);
title('Señal al Cuadrado: v(t)^2', 'FontSize', 12, 'FontWeight', 'bold');
hold on;
valor_medio = mean(senal.^2);
yline(valor_medio, 'k--', sprintf('Media = %.2f V^2', valor_medio), ...
    'LineWidth', 2, 'LabelHorizontalAlignment', 'left');
hold off;

subplot(2,1,2);
valores_rms_acumulados = zeros(1, N_muestras);
for i = 1:N_muestras
    valores_rms_acumulados(i) = sqrt(mean(senal(1:i).^2));
end
plot(t*1000, valores_rms_acumulados, 'c-', 'LineWidth', 2);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 11);
ylabel('Valor RMS (V)', 'FontSize', 11);
title('Convergencia del Valor RMS', 'FontSize', 12, 'FontWeight', 'bold');
ylim([0 250]);
hold on;
yline(V_rms_teorico, 'r--', sprintf('RMS teórico = %.2f V', V_rms_teorico), ...
    'LineWidth', 2, 'LabelHorizontalAlignment', 'right');
hold off;

fprintf('Gráficos generados exitosamente.\n\n');

%% 9. RESUMEN FINAL
fprintf('========================================\n');
fprintf('         RESUMEN EJECUTIVO\n');
fprintf('========================================\n\n');
fprintf('La función calcularRMS() ha sido probada exitosamente.\n');
fprintf('El valor RMS calculado es %.4f V con un error de %.4f%%\n', ...
    V_rms_calculado, error_porcentual);
fprintf('respecto al valor de referencia de 230 V.\n\n');
fprintf('Programa finalizado.\n');
fprintf('========================================\n');