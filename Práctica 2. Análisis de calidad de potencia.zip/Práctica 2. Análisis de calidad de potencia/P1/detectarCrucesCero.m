function [indices_cruces, frecuencia] = detectarCrucesCero(senal, fs)
    % detectarCrucesCero - Detecta los cruces por cero de una señal
    %
    % Sintaxis: [indices_cruces, frecuencia] = detectarCrucesCero(senal, fs)
    %
    % Entradas:
    %   senal - Vector con los valores de la señal (array numérico)
    %   fs - Frecuencia de muestreo en Hz (escalar)
    %
    % Salidas:
    %   indices_cruces - Vector con los índices donde ocurren cruces por cero
    %   frecuencia - Frecuencia estimada de la señal en Hz
    %
    % Descripción:
    %   Esta función detecta los puntos donde la señal cruza por cero
    %   utilizando la función sign() para identificar cambios de signo.
    %   Calcula la frecuencia considerando que dos cruces consecutivos
    %   representan medio ciclo de la señal.
    %
    % Ejemplo:
    %   t = 0:0.001:1;
    %   senal = sin(2*pi*5*t);
    %   [cruces, freq] = detectarCrucesCero(senal, 1000);
    %
    % Autor: [Tu nombre]
    % Fecha: [Fecha actual]
    
    % Validación de entradas
    if ~isnumeric(senal) || ~isvector(senal)
        error('La señal debe ser un vector numérico');
    end
    
    if ~isnumeric(fs) || ~isscalar(fs) || fs <= 0
        error('La frecuencia de muestreo debe ser un escalar positivo');
    end
    
    if length(senal) < 3
        error('La señal debe tener al menos 3 muestras');
    end
    
    % Obtener el signo de cada muestra
    % sign() devuelve: 1 para positivos, -1 para negativos, 0 para cero
    signos = sign(senal);
    
    % Manejar el caso donde hay valores exactamente en cero
    % Los valores cero toman el signo del valor anterior
    for i = 2:length(signos)
        if signos(i) == 0
            signos(i) = signos(i-1);
        end
    end
    
    % Detectar cambios de signo
    % Un cruce por cero ocurre cuando sign(n) != sign(n+1)
    cambios_signo = diff(signos);
    
    % Los cruces por cero están donde cambios_signo != 0
    indices_cruces = find(cambios_signo ~= 0);
    
    % Ajustar índices: el cruce ocurre entre el índice i e i+1
    % Usamos i como referencia (antes del cruce)
    
    % Calcular la frecuencia
    if length(indices_cruces) < 2
        warning('No se encontraron suficientes cruces por cero para calcular frecuencia');
        frecuencia = NaN;
    else
        % Calcular diferencias de tiempo entre cruces consecutivos
        diferencias_indices = diff(indices_cruces);
        
        % Tiempo promedio entre cruces (en muestras)
        tiempo_entre_cruces_muestras = mean(diferencias_indices);
        
        % Convertir a tiempo en segundos
        tiempo_entre_cruces_seg = tiempo_entre_cruces_muestras / fs;
        
        % Dos cruces consecutivos = medio ciclo
        % Por lo tanto: T = 2 * tiempo_entre_cruces
        periodo = 2 * tiempo_entre_cruces_seg;
        
        % Frecuencia = 1 / T
        frecuencia = 1 / periodo;
    end
    
end