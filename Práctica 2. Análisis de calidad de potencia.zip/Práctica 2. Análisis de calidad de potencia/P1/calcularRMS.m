function valor_rms = calcularRMS(senal)
    % calcularRMS - Calcula el valor RMS de una señal discreta
    %
    % Sintaxis: valor_rms = calcularRMS(senal)
    %
    % Entrada:
    %   senal - Vector con los valores de la señal (array numérico)
    %
    % Salida:
    %   valor_rms - Valor RMS calculado (escalar)
    %
    % Descripción:
    %   Esta función calcula el valor RMS (Root Mean Square) de una señal
    %   discreta usando la fórmula:
    %
    %   V_RMS = sqrt(1/N * sum(v_i^2))
    %
    %   donde:
    %   - N es el número de muestras
    %   - v_i son los valores de cada muestra
    %
    % Ejemplo:
    %   t = 0:0.001:0.1;
    %   senal = 325 * sin(2*pi*50*t);
    %   rms = calcularRMS(senal);
    %
    % Autor: [Tu nombre]
    % Fecha: [Fecha actual]
    
    % Validación de entrada
    if ~isnumeric(senal) || ~isvector(senal)
        error('La entrada debe ser un vector numérico');
    end
    
    if isempty(senal)
        error('El vector de señal no puede estar vacío');
    end
    
    % Número de muestras
    N = length(senal);
    
    % Cálculo del valor RMS usando la fórmula
    % V_RMS = sqrt(1/N * sum(v_i^2))
    valor_rms = sqrt((1/N) * sum(senal.^2));
    
end