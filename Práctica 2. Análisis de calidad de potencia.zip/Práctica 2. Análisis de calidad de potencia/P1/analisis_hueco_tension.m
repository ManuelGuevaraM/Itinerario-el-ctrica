clear; clc; close all;

%% 1. Parámetros de la señal base
fs = 2000;              % Frecuencia de muestreo [Hz]
t_total = 0.2;          % Duración total [s]
t = 0:1/fs:t_total;     % Vector de tiempo
f = 50;                 % Frecuencia de la señal [Hz]
A = 325;                % Amplitud pico [V]

% Señal base
signal = A * sin(2*pi*f*t);

%% 2. Introducir hueco de tensión
inicio_hueco = 0.05;    % [s]
duracion_hueco = 0.05;  % [s]
profundidad = 0.5;      % 50%

idx_inicio = round(inicio_hueco * fs);
idx_fin = round((inicio_hueco + duracion_hueco) * fs);
signal(idx_inicio:idx_fin) = signal(idx_inicio:idx_fin) * profundidad;

%% 3. Calcular RMS deslizante
window_ms = 20; % 1 ciclo de 50 Hz = 20 ms
[rms_vals, t_rms] = rms_ventanas(signal, fs, window_ms);

%% 4. Visualización de resultados
V_nominal = 230; 
V_limite = 0.9 * V_nominal; % 10% de caída

figure('Position', [100 100 800 600]);

subplot(2,1,1);
plot(t, signal, 'b');
title('Señal de tensión con hueco');
xlabel('Tiempo [s]');
ylabel('Amplitud [V]');
grid on;
ylim([-350 350]);

subplot(2,1,2);
plot(t_rms, rms_vals, 'r', 'LineWidth', 1.2); hold on;
yline(V_nominal, '--k', '230V (Nominal)');
yline(V_limite, '--g', '207V (-10%)');
title('Valor RMS deslizante');
xlabel('Tiempo [s]');
ylabel('RMS [V]');
grid on;
legend('RMS','Nominal','Límite -10%','Location','best');

saveas(gcf, 'resultados_hueco_tension.png');

%% 5. Análisis automático
[min_rms, idx_min] = min(rms_vals);
t_min = t_rms(idx_min);

fprintf('\n--- RESULTADOS ---\n');
fprintf('Inicio del hueco detectado en: %.4f s\n', t_rms(find(rms_vals < V_limite, 1, 'first')));
fprintf('Valor RMS mínimo: %.2f V\n', min_rms);
fprintf('Tiempo al que el RMS vuelve a 230V: %.4f s\n', t_rms(find(rms_vals > 229, 1, 'last')));
fprintf('Duración del hueco (RMS < 207V): %.4f s\n', sum(rms_vals < V_limite)/fs);
