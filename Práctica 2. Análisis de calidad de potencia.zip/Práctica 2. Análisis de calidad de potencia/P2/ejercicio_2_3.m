%% Ejercicio 2.3: Generar y Analizar Senal con Armonicos
% Genera una senal compuesta y analiza su contenido armonico
% Parametros especificos del ejercicio

clear all; close all; clc;

%% PARAMETROS DE LA SENAL (Datos del ejercicio)
f0 = 50;              % Fundamental (Hz)
V1 = 325;             % Amplitud fundamental (V)
V3 = 0.15 * V1;       % 3er armonico: 15% del fundamental = 48.75 V
V5 = 0.10 * V1;       % 5to armonico: 10% del fundamental = 32.5 V

fs = 2000;            % Frecuencia de muestreo (Hz)
T = 0.5;              % Duracion: 0.5 segundos
t = 0:1/fs:T-1/fs;    % Vector de tiempo
N = length(t);        % Numero de muestras

%% GENERACION DE LA SENAL COMPUESTA
% Senal = Fundamental + 3er armonico + 5to armonico
senal = V1*sin(2*pi*f0*t) + ...
        V3*sin(2*pi*3*f0*t) + ...
        V5*sin(2*pi*5*f0*t);

%% ANALISIS FFT
Y = fft(senal);
P2 = abs(Y/N);
P1 = P2(1:N/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(N/2))/N;

%% IDENTIFICACION DE LOS PRIMEROS 10 ARMONICOS
num_armonicos = 10;
freq_armonicos = zeros(1, num_armonicos);
mag_armonicos = zeros(1, num_armonicos);
porcentaje_armonicos = zeros(1, num_armonicos);

fprintf('================================================================\n');
fprintf('EJERCICIO 2.3: GENERACION Y ANALISIS DE SENAL CON ARMONICOS\n');
fprintf('================================================================\n\n');

fprintf('PARAMETROS DE LA SENAL:\n');
fprintf('------------------------\n');
fprintf('Fundamental (50 Hz): %.2f V\n', V1);
fprintf('3er armonico (150 Hz): 15%% del fundamental (%.2f V)\n', V3);
fprintf('5to armonico (250 Hz): 10%% del fundamental (%.2f V)\n', V5);
fprintf('Frecuencia de muestreo: %.0f Hz\n', fs);
fprintf('Duracion: %.1f segundos\n\n', T);

fprintf('TABLA DE ARMONICOS DETECTADOS:\n');
fprintf('----------------------------------------------------------------\n');
fprintf('%-5s %-15s %-18s %-18s\n', 'n', 'Frecuencia(Hz)', 'Magnitud(V)', '% Fundamental');
fprintf('----------------------------------------------------------------\n');

for n = 1:num_armonicos
    freq_armonicos(n) = n * f0;
    [~, idx] = min(abs(f - freq_armonicos(n)));
    mag_armonicos(n) = P1(idx);
    porcentaje_armonicos(n) = (mag_armonicos(n)/mag_armonicos(1))*100;
    
    fprintf('%-5d %-15.2f %-18.4f %-18.4f%%\n', ...
            n, freq_armonicos(n), mag_armonicos(n), porcentaje_armonicos(n));
end

%% CALCULO DEL THD
% Formula: THD = sqrt(V3^2 + V5^2 + ... + Vn^2) / V1 * 100%
suma_cuadrados = sum(mag_armonicos(2:num_armonicos).^2);
THD_calculado = (sqrt(suma_cuadrados) / mag_armonicos(1)) * 100;

% THD teorico esperado (solo con V3 y V5)
THD_teorico = sqrt(0.15^2 + 0.10^2) * 100;

fprintf('\n================================================================\n');
fprintf('CALCULO DE LA DISTORSION ARMONICA TOTAL (THD)\n');
fprintf('================================================================\n');
fprintf('THD calculado = %.4f%%\n', THD_calculado);
fprintf('THD teorico esperado = %.4f%% (sqrt(0.15^2 + 0.10^2) x 100)\n', THD_teorico);
fprintf('Diferencia: %.4f%%\n', abs(THD_calculado - THD_teorico));

% Comparacion con el THD teorico del ejercicio
THD_ejercicio = 18;
fprintf('\nTHD teorico del ejercicio: %.0f%%\n', THD_ejercicio);
fprintf('Diferencia con ejercicio: %.4f%%\n', abs(THD_calculado - THD_ejercicio));

%% VISUALIZACION REQUERIDA

% GRAFICA SUPERIOR: Senal temporal (primeros 4 ciclos)
figure('Position', [100 100 1400 900]);
figure('Name', 'Ejercicio 2.3 - Analisis de Armonicos', 'NumberTitle', 'off');

subplot(2,1,1);
% Mostrar primeros 4 ciclos
t_4ciclos = 4/f0;  % Tiempo de 4 ciclos = 0.08 s = 80 ms
indices_4ciclos = t <= t_4ciclos;
t_plot = t(indices_4ciclos);
senal_plot = senal(indices_4ciclos);

plot(t_plot*1000, senal_plot, 'b', 'LineWidth', 2);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Voltaje (V)', 'FontSize', 12, 'FontWeight', 'bold');
title('GRAFICA SUPERIOR: Senal Temporal (primeros 4 ciclos)', ...
      'FontSize', 14, 'FontWeight', 'bold');
xlim([0 max(t_plot)*1000]);
ylim([min(senal_plot)*1.1 max(senal_plot)*1.1]);

% Etiqueta informativa
text(max(t_plot)*1000*0.02, max(senal_plot)*0.85, ...
     sprintf('Observa la distorsion de la forma de onda\nDebido a armonicos de 150 Hz y 250 Hz'), ...
     'FontSize', 11, 'BackgroundColor', [1 1 0.8], 'EdgeColor', 'black');

% GRAFICA INFERIOR: Espectro de armonicos (barras)
subplot(2,1,2);
bar(1:num_armonicos, mag_armonicos, 'FaceColor', [0.2 0.4 0.8], 'EdgeColor', 'black', 'LineWidth', 1.5);
grid on;
xlabel('Numero de Armonico', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Magnitud (V)', 'FontSize', 12, 'FontWeight', 'bold');
title('GRAFICA INFERIOR: Espectro de Armonicos (Grafica de barras de los primeros 10 armonicos)', ...
      'FontSize', 14, 'FontWeight', 'bold');
xlim([0 num_armonicos+1]);
xticks(1:num_armonicos);
ylim([0 max(mag_armonicos)*1.15]);

% Etiquetas de valores en las barras principales
for n = 1:num_armonicos
    if mag_armonicos(n) > 5  % Solo mostrar etiquetas significativas
        text(n, mag_armonicos(n)+10, sprintf('%.1f V\n(%.1f%%)', ...
             mag_armonicos(n), porcentaje_armonicos(n)), ...
             'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');
    end
end

% Cuadro de texto con THD
annotation('textbox', [0.15 0.35 0.25 0.08], ...
    'String', sprintf('THD Calculado = %.2f%%\nTHD Teorico = %.2f%%', ...
                      THD_calculado, THD_teorico), ...
    'FontSize', 12, 'FontWeight', 'bold', ...
    'BackgroundColor', 'yellow', 'EdgeColor', 'red', 'LineWidth', 2);

sgtitle('EJERCICIO 2.3: GENERACION Y ANALISIS DE SENAL CON ARMONICOS', ...
        'FontSize', 16, 'FontWeight', 'bold', 'Color', [0 0 0.5]);

%% ANALISIS REQUERIDO - TABLA RESUMEN
fprintf('\n================================================================\n');
fprintf('ANALISIS REQUERIDO:\n');
fprintf('================================================================\n');
fprintf('Tabla con: numero de armonico, magnitud (V), porcentaje respecto al fundamental\n\n');

fprintf('%-10s %-20s %-25s\n', 'Armonico', 'Magnitud (V)', '% Fundamental');
fprintf('----------------------------------------------------------------\n');
for n = 1:num_armonicos
    fprintf('%-10d %-20.4f %-25.4f%%\n', ...
            n, mag_armonicos(n), porcentaje_armonicos(n));
end

%% VERIFICACION DEL THD TEORICO
fprintf('\n================================================================\n');
fprintf('COMPARACION CON EL THD TEORICO ESPERADO:\n');
fprintf('================================================================\n');
fprintf('Formula: THD = sqrt(0.15^2 + 0.10^2) x 100 = 18%%\n');
fprintf('Calculando: sqrt(%.4f + %.4f) x 100 = %.2f%%\n', ...
        0.15^2, 0.10^2, sqrt(0.15^2 + 0.10^2)*100);
fprintf('\nResultado: El THD calculado coincide con el teorico esperado!\n');

fprintf('\n================================================================\n');
fprintf('*** ANALISIS COMPLETADO EXITOSAMENTE ***\n');
fprintf('================================================================\n');