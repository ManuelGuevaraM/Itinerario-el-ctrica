%% Ejercicio 2.1: Analisis Espectral Basico
% Implementa una funcion para calcular el espectro de frecuencias usando FFT
% Especificaciones del ejercicio

clear all; close all; clc;

%% PARAMETROS SEGUN EL EJERCICIO
% Senal sinusoidal pura de 50 Hz
f0 = 50;              % Frecuencia de la senal (Hz)
fs = 2000;            % Frecuencia de muestreo (Hz)
T = 1;                % Duracion: 1 segundo
A = 325;              % Amplitud pico: 325 V

% Vector de tiempo
t = 0:1/fs:T-1/fs;
N = length(t);        % Numero de muestras

%% GENERACION DE LA SENAL SINUSOIDAL PURA (50 Hz)
senal = A * sin(2*pi*f0*t);

fprintf('================================================================\n');
fprintf('EJERCICIO 2.1: ANALISIS ESPECTRAL BASICO\n');
fprintf('================================================================\n\n');

fprintf('PARAMETROS DE LA SENAL:\n');
fprintf('------------------------\n');
fprintf('Frecuencia de la senal: %.0f Hz\n', f0);
fprintf('Frecuencia de muestreo: %.0f Hz\n', fs);
fprintf('Duracion: %.0f segundo\n', T);
fprintf('Amplitud pico: %.0f V\n', A);
fprintf('Numero de muestras: %d\n\n', N);

%% CALCULO DEL ESPECTRO USANDO FFT
fprintf('PASO 1: Calcular FFT de la senal\n');
fprintf('----------------------------------\n');

% Aplicar FFT
Y = fft(senal);

% Calcular el espectro de magnitudes
P2 = abs(Y/N);              % Espectro bilateral normalizado
P1 = P2(1:N/2+1);           % Espectro unilateral (frecuencias positivas)
P1(2:end-1) = 2*P1(2:end-1); % Multiplicar por 2 (excepto DC y Nyquist)

% Vector de frecuencias correspondiente
f = fs*(0:(N/2))/N;

fprintf('FFT calculada correctamente\n');
fprintf('Longitud del espectro: %d puntos\n\n', length(P1));

%% SALIDA: VECTOR DE FRECUENCIAS Y MAGNITUDES
fprintf('PASO 2: Generar vectores de salida\n');
fprintf('------------------------------------\n');
fprintf('Vector de frecuencias: %.0f puntos\n', length(f));
fprintf('Rango: %.2f Hz a %.2f Hz\n', f(1), f(end));
fprintf('Vector de magnitudes: %.0f puntos\n\n', length(P1));

%% CONSIDERACIONES: SOLO FRECUENCIAS POSITIVAS (Primera mitad)
fprintf('PASO 3: Considerar solo frecuencias positivas\n');
fprintf('----------------------------------------------\n');
fprintf('Se trabaja con la primera mitad del espectro\n');
fprintf('Razon: El espectro es simetrico para senales reales\n\n');

%% NORMALIZACION: Dividir por numero de muestras
fprintf('PASO 4: Normalizar magnitudes\n');
fprintf('------------------------------\n');
fprintf('Division por N = %d muestras\n', N);
fprintf('Magnitudes en valores absolutos (no en dB)\n\n');

%% VISUALIZACION HASTA 500 Hz
fprintf('PASO 5: Visualizacion del espectro (hasta 500 Hz)\n');
fprintf('--------------------------------------------------\n');

% Encontrar indices para frecuencias hasta 500 Hz
idx_500Hz = f <= 500;
f_plot = f(idx_500Hz);
P1_plot = P1(idx_500Hz);

fprintf('Rango visualizado: 0 - 500 Hz\n');
fprintf('Numero de puntos en el grafico: %d\n\n', sum(idx_500Hz));

%% VERIFICACION: PICO EN 50 Hz
fprintf('PASO 6: Verificacion del pico en 50 Hz\n');
fprintf('---------------------------------------\n');

% Buscar el pico maximo
[mag_max, idx_max] = max(P1);
freq_max = f(idx_max);

fprintf('Frecuencia del pico detectado: %.2f Hz\n', freq_max);
fprintf('Magnitud del pico: %.4f V\n', mag_max);
fprintf('Amplitud teorica esperada: %.2f V\n', A);
fprintf('Error: %.6f V (%.4f%%)\n\n', abs(mag_max - A), abs(mag_max - A)/A*100);

% Verificar que solo hay un pico significativo en 50 Hz
umbral = 1;  % 1 V como umbral de deteccion
picos_significativos = sum(P1 > umbral);
fprintf('Numero de picos significativos (> %.0f V): %d\n', umbral, picos_significativos);

if picos_significativos == 1 && abs(freq_max - f0) < 1
    fprintf('VERIFICACION EXITOSA: Un solo pico en 50 Hz\n\n');
else
    fprintf('ATENCION: Se detectaron multiplos picos o frecuencia incorrecta\n\n');
end

%% GRAFICAS
figure('Position', [100 100 1400 900]);
figure('Name', 'Ejercicio 2.1 - Analisis Espectral Basico', 'NumberTitle', 'off');

% Grafica 1: Senal temporal
subplot(3,1,1);
t_5ciclos = 5/f0;  % Mostrar 5 ciclos completos
idx_5ciclos = t <= t_5ciclos;
plot(t(idx_5ciclos)*1000, senal(idx_5ciclos), 'b', 'LineWidth', 2);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Amplitud (V)', 'FontSize', 12, 'FontWeight', 'bold');
title('SENAL TEMPORAL: Sinusoidal pura de 50 Hz (5 ciclos)', ...
      'FontSize', 14, 'FontWeight', 'bold');
xlim([0 t_5ciclos*1000]);

% Anotacion
text(t_5ciclos*1000*0.02, A*0.8, ...
     sprintf('Frecuencia: %.0f Hz\nAmplitud: %.0f V\nPeriodo: %.1f ms', ...
             f0, A, 1000/f0), ...
     'FontSize', 11, 'BackgroundColor', [1 1 0.8], 'EdgeColor', 'black');

% Grafica 2: Espectro completo hasta 500 Hz
subplot(3,1,2);
plot(f_plot, P1_plot, 'r', 'LineWidth', 2);
hold on;
stem(freq_max, mag_max, 'b', 'LineWidth', 3, 'MarkerSize', 10);
grid on;
xlabel('Frecuencia (Hz)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Magnitud (V)', 'FontSize', 12, 'FontWeight', 'bold');
title('ESPECTRO DE FRECUENCIAS: Visualizacion hasta 500 Hz', ...
      'FontSize', 14, 'FontWeight', 'bold');
xlim([0 500]);
ylim([0 max(P1_plot)*1.15]);
legend('Espectro FFT', sprintf('Pico en %.0f Hz', freq_max), ...
       'Location', 'northeast', 'FontSize', 11);

% Anotacion del pico
text(freq_max+20, mag_max*0.9, ...
     sprintf('Pico detectado:\nf = %.2f Hz\nMag = %.2f V', freq_max, mag_max), ...
     'FontSize', 11, 'BackgroundColor', 'yellow', 'EdgeColor', 'red', 'LineWidth', 2);

% Grafica 3: Zoom del espectro alrededor de 50 Hz
subplot(3,1,3);
% Rango de 0 a 150 Hz para ver detalle
idx_zoom = f <= 150;
f_zoom = f(idx_zoom);
P1_zoom = P1(idx_zoom);

stem(f_zoom, P1_zoom, 'b', 'LineWidth', 2, 'MarkerSize', 8);
grid on;
xlabel('Frecuencia (Hz)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Magnitud (V)', 'FontSize', 12, 'FontWeight', 'bold');
title('ZOOM DEL ESPECTRO: Detalle de 0 a 150 Hz', ...
      'FontSize', 14, 'FontWeight', 'bold');
xlim([0 150]);
ylim([0 max(P1_zoom)*1.15]);

% Marcar exactamente 50 Hz
line([f0 f0], [0 mag_max], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
text(f0+5, mag_max*1.05, ...
     sprintf('50 Hz\n%.2f V', mag_max), ...
     'FontSize', 12, 'FontWeight', 'bold', 'Color', 'red');

sgtitle('EJERCICIO 2.1: ANALISIS ESPECTRAL BASICO USANDO FFT', ...
        'FontSize', 16, 'FontWeight', 'bold', 'Color', [0 0 0.5]);

%% PRUEBA: GENERAR SENAL SINUSOIDAL PURA DE 50 Hz
fprintf('================================================================\n');
fprintf('PRUEBA DEL EJERCICIO:\n');
fprintf('================================================================\n');
fprintf('Senal generada: Sinusoidal pura de 50 Hz\n');
fprintf('Frecuencia de muestreo: 2000 Hz\n');
fprintf('Duracion: 1 segundo\n');
fprintf('Amplitud pico: 325 V\n\n');

fprintf('RESULTADOS DE LA PRUEBA:\n');
fprintf('------------------------\n');
fprintf('1. Pico detectado en: %.2f Hz (esperado: 50 Hz)\n', freq_max);
fprintf('2. Magnitud del pico: %.4f V (esperado: 325 V)\n', mag_max);
fprintf('3. Numero de picos significativos: %d (esperado: 1)\n', picos_significativos);
fprintf('4. Error de frecuencia: %.4f Hz\n', abs(freq_max - f0));
fprintf('5. Error de amplitud: %.4f V (%.4f%%)\n', ...
        abs(mag_max - A), abs(mag_max - A)/A*100);

if abs(freq_max - f0) < 1 && abs(mag_max - A)/A < 0.01
    fprintf('\n*** PRUEBA EXITOSA: Todos los parametros dentro de tolerancia ***\n');
else
    fprintf('\n*** ATENCION: Revisar parametros fuera de tolerancia ***\n');
end

fprintf('================================================================\n');

%% RESUMEN TECNICO
fprintf('\nRESUMEN TECNICO DEL ANALISIS FFT:\n');
fprintf('----------------------------------\n');
fprintf('Resolucion de frecuencia: df = fs/N = %.4f Hz\n', fs/N);
fprintf('Frecuencia de Nyquist: fN = fs/2 = %.0f Hz\n', fs/2);
fprintf('Rango de frecuencias analizadas: 0 - %.0f Hz\n', fs/2);
fprintf('Ventana temporal: %.2f s\n', T);
fprintf('Numero total de muestras: %d\n', N);

fprintf('\n*** ANALISIS COMPLETADO EXITOSAMENTE ***\n');
fprintf('================================================================\n');