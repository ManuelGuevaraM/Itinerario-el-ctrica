%% Ejercicio 2.2: Analisis de Armonicos
% Analisis completo de los primeros 15 armonicos de una senal de 50 Hz

clear all; close all; clc;

%% PARAMETROS DE LA SENAL
f0 = 50;              % Frecuencia fundamental (Hz)
fs = 2000;            % Frecuencia de muestreo (Hz)
T = 0.5;              % Duracion de la senal (segundos)
t = 0:1/fs:T-1/fs;    % Vector de tiempo
N = length(t);        % Numero de muestras

%% GENERACION DE SENAL CON ARMONICOS
% Fundamental (50 Hz) + armonicos impares tipicos
V1 = 325;             % Amplitud del fundamental (V)
V3 = 0.15 * V1;       % 3er armonico: 15% del fundamental
V5 = 0.10 * V1;       % 5to armonico: 10% del fundamental
V7 = 0.08 * V1;       % 7mo armonico: 8% del fundamental
V9 = 0.05 * V1;       % 9no armonico: 5% del fundamental

% Senal compuesta
senal = V1*sin(2*pi*f0*t) + ...
        V3*sin(2*pi*3*f0*t) + ...
        V5*sin(2*pi*5*f0*t) + ...
        V7*sin(2*pi*7*f0*t) + ...
        V9*sin(2*pi*9*f0*t);

%% ANALISIS FFT
Y = fft(senal);
P2 = abs(Y/N);
P1 = P2(1:N/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = fs*(0:(N/2))/N;

%% IDENTIFICACION Y CUANTIFICACION DE ARMONICOS
num_armonicos = 15;
freq_armonicos = zeros(1, num_armonicos);
mag_armonicos = zeros(1, num_armonicos);

fprintf('========================================\n');
fprintf('ANALISIS DE ARMONICOS\n');
fprintf('========================================\n');
fprintf('Frecuencia fundamental: %.2f Hz\n\n', f0);

% Resolucion de frecuencia
df = fs/N;
fprintf('Resolucion de frecuencia: df = %.4f Hz\n\n', df);

fprintf('Tabla de Armonicos:\n');
fprintf('%-5s %-15s %-15s %-15s\n', 'n', 'Freq (Hz)', 'Magnitud (V)', '% Fund');
fprintf('--------------------------------------------------------\n');

for n = 1:num_armonicos
    % Frecuencia del armonico n
    freq_armonicos(n) = n * f0;
    
    % Buscar el indice mas cercano en el espectro
    [~, idx] = min(abs(f - freq_armonicos(n)));
    
    % Magnitud del armonico
    mag_armonicos(n) = P1(idx);
    
    % Porcentaje respecto al fundamental
    porcentaje = (mag_armonicos(n)/mag_armonicos(1))*100;
    
    fprintf('%-5d %-15.2f %-15.4f %-15.2f%%\n', ...
            n, freq_armonicos(n), mag_armonicos(n), porcentaje);
end

%% CALCULO DEL THD (Total Harmonic Distortion)
suma_cuadrados = sum(mag_armonicos(2:num_armonicos).^2);
THD = (sqrt(suma_cuadrados) / mag_armonicos(1)) * 100;

fprintf('\n========================================\n');
fprintf('DISTORSION ARMONICA TOTAL (THD)\n');
fprintf('========================================\n');
fprintf('THD = %.4f%%\n', THD);

% Comparacion con THD teorico esperado
THD_teorico = sqrt(0.15^2 + 0.10^2) * 100;
fprintf('THD teorico esperado: %.4f%%\n', THD_teorico);
fprintf('Diferencia: %.4f%%\n', abs(THD - THD_teorico));

%% GRAFICAS

% Grafica 1: Senal temporal (primeros 4 ciclos)
figure('Position', [100 100 1200 800]);

subplot(3,1,1);
t_plot = t(t <= 4/f0);
senal_plot = senal(t <= 4/f0);
plot(t_plot*1000, senal_plot, 'b', 'LineWidth', 1.5);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 11);
ylabel('Voltaje (V)', 'FontSize', 11);
title('Senal Temporal - Primeros 4 Ciclos', 'FontSize', 12, 'FontWeight', 'bold');
xlim([0 max(t_plot)*1000]);

% Grafica 2: Espectro de frecuencia completo
subplot(3,1,2);
plot(f, P1, 'r', 'LineWidth', 1);
hold on;
stem(freq_armonicos, mag_armonicos, 'b', 'LineWidth', 2, 'MarkerSize', 8);
grid on;
xlabel('Frecuencia (Hz)', 'FontSize', 11);
ylabel('Magnitud (V)', 'FontSize', 11);
title('Espectro de Frecuencia - Todos los Armonicos', 'FontSize', 12, 'FontWeight', 'bold');
xlim([0 800]);
legend('Espectro FFT', 'Armonicos detectados', 'Location', 'northeast');

% Grafica 3: Grafica de barras de armonicos
subplot(3,1,3);
bar(1:num_armonicos, mag_armonicos, 'FaceColor', [0.2 0.6 0.8]);
grid on;
xlabel('Numero de Armonico', 'FontSize', 11);
ylabel('Magnitud (V)', 'FontSize', 11);
title('Magnitud de los Primeros 15 Armonicos', 'FontSize', 12, 'FontWeight', 'bold');
xlim([0 num_armonicos+1]);
xticks(1:num_armonicos);

% Anadir texto con THD
text(num_armonicos-3, max(mag_armonicos)*0.9, ...
     sprintf('THD = %.2f%%', THD), ...
     'FontSize', 12, 'FontWeight', 'bold', ...
     'BackgroundColor', 'yellow', 'EdgeColor', 'black');

sgtitle('ANALISIS DE ARMONICOS - Ejercicio 2.2', ...
        'FontSize', 14, 'FontWeight', 'bold');

%% PARAMETROS DE LA SENAL
fprintf('\n========================================\n');
fprintf('PARAMETROS DE LA SENAL\n');
fprintf('========================================\n');
fprintf('Frecuencia de muestreo: %.0f Hz\n', fs);
fprintf('Numero de muestras: %d\n', N);
fprintf('Duracion: %.2f s\n', T);
fprintf('Resolucion de frecuencia: %.4f Hz\n', df);
fprintf('\n========================================\n');

fprintf('\n*** Analisis completado ***\n');