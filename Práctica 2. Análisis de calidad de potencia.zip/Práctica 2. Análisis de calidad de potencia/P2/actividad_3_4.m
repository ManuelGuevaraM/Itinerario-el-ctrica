%% Actividad 3.4: Comparar Diferentes Cargas Electricas
% Objetivo: Simular y comparar el contenido armonico de tres tipos de cargas
% Autor: Analisis de Ingenieria Electrica

clear all; close all; clc;

%% PARAMETROS GENERALES
f0 = 50;              % Frecuencia fundamental (Hz)
fs = 5000;            % Frecuencia de muestreo (Hz)
T = 0.5;              % Duracion (segundos)
t = 0:1/fs:T-1/fs;    % Vector de tiempo
N = length(t);        % Numero de muestras

%% ===================================================================
%% TAREA 1: GENERAR LAS TRES SENALES CON LOS PARAMETROS INDICADOS
%% ===================================================================

fprintf('================================================================\n');
fprintf('ACTIVIDAD 3.4: COMPARACION DE DIFERENTES CARGAS ELECTRICAS\n');
fprintf('================================================================\n\n');

% ------------------------------------------------------------------
% CARGA 1: LINEAL (IDEAL) - THD esperado aprox 0%
% ------------------------------------------------------------------
fprintf('CARGA 1: LINEAL (IDEAL)\n');
fprintf('-----------------------\n');
V1_lineal = 325;      % Solo fundamental de 50 Hz, Amplitud 325 V
THD_esperado_lineal = 0;

% Senal: Solo fundamental
senal_lineal = V1_lineal * sin(2*pi*f0*t);

fprintf('- Solo fundamental de 50 Hz\n');
fprintf('- Amplitud: %.0f V\n', V1_lineal);
fprintf('- THD esperado: aprox %.0f%%\n\n', THD_esperado_lineal);

% ------------------------------------------------------------------
% CARGA 2: DISTORSION MODERADA - THD esperado aprox 11.2%
% ------------------------------------------------------------------
fprintf('CARGA 2: DISTORSION MODERADA\n');
fprintf('----------------------------\n');
V1_moderada = 325;              % Fundamental: 325 V
V3_moderada = 0.10 * V1_moderada;  % 3er armonico: 10% (32.5 V)
V5_moderada = 0.05 * V1_moderada;  % 5to armonico: 5% (16.25 V)
THD_esperado_moderada = 11.2;

% Senal compuesta
senal_moderada = V1_moderada * sin(2*pi*f0*t) + ...
                 V3_moderada * sin(2*pi*3*f0*t) + ...
                 V5_moderada * sin(2*pi*5*f0*t);

fprintf('- Fundamental: %.0f V\n', V1_moderada);
fprintf('- 3er armonico: 10%% (%.2f V)\n', V3_moderada);
fprintf('- 5to armonico: 5%% (%.2f V)\n', V5_moderada);
fprintf('- THD esperado: aprox %.1f%%\n\n', THD_esperado_moderada);

% ------------------------------------------------------------------
% CARGA 3: ALTAMENTE DISTORSIONADA - THD esperado aprox 30.4%
% ------------------------------------------------------------------
fprintf('CARGA 3: ALTAMENTE DISTORSIONADA\n');
fprintf('--------------------------------\n');
V1_distorsionada = 325;                    % Fundamental: 325 V
V3_distorsionada = 0.25 * V1_distorsionada;  % 3er armonico: 25% (81.25 V)
V5_distorsionada = 0.15 * V1_distorsionada;  % 5to armonico: 15% (48.75 V)
V7_distorsionada = 0.10 * V1_distorsionada;  % 7mo armonico: 10% (32.5 V)
THD_esperado_distorsionada = 30.4;

% Senal compuesta
senal_distorsionada = V1_distorsionada * sin(2*pi*f0*t) + ...
                      V3_distorsionada * sin(2*pi*3*f0*t) + ...
                      V5_distorsionada * sin(2*pi*5*f0*t) + ...
                      V7_distorsionada * sin(2*pi*7*f0*t);

fprintf('- Fundamental: %.0f V\n', V1_distorsionada);
fprintf('- 3er armonico: 25%% (%.2f V)\n', V3_distorsionada);
fprintf('- 5to armonico: 15%% (%.2f V)\n', V5_distorsionada);
fprintf('- 7mo armonico: 10%% (%.2f V)\n', V7_distorsionada);
fprintf('- THD esperado: aprox %.1f%%\n\n', THD_esperado_distorsionada);

%% ===================================================================
%% TAREA 2: APLICAR FUNCION DE ANALISIS DE ARMONICOS A CADA UNA
%% ===================================================================

fprintf('================================================================\n');
fprintf('TAREA 2: ANALISIS DE ARMONICOS DE CADA CARGA\n');
fprintf('================================================================\n\n');

% Numero de armonicos a analizar
num_armonicos = 15;

% --- ANALISIS CARGA LINEAL ---
[freq_lineal, mag_lineal, THD_lineal] = analizar_armonicos(senal_lineal, fs, f0, num_armonicos);

fprintf('RESULTADOS CARGA LINEAL:\n');
fprintf('THD Calculado: %.4f%%\n', THD_lineal);
fprintf('THD Esperado: %.1f%%\n', THD_esperado_lineal);
fprintf('Diferencia: %.4f%%\n\n', abs(THD_lineal - THD_esperado_lineal));

% --- ANALISIS CARGA MODERADA ---
[freq_moderada, mag_moderada, THD_moderada] = analizar_armonicos(senal_moderada, fs, f0, num_armonicos);

fprintf('RESULTADOS CARGA MODERADA:\n');
fprintf('THD Calculado: %.4f%%\n', THD_moderada);
fprintf('THD Esperado: %.1f%%\n', THD_esperado_moderada);
fprintf('Diferencia: %.4f%%\n\n', abs(THD_moderada - THD_esperado_moderada));

% --- ANALISIS CARGA DISTORSIONADA ---
[freq_distorsionada, mag_distorsionada, THD_distorsionada] = analizar_armonicos(senal_distorsionada, fs, f0, num_armonicos);

fprintf('RESULTADOS CARGA DISTORSIONADA:\n');
fprintf('THD Calculado: %.4f%%\n', THD_distorsionada);
fprintf('THD Esperado: %.1f%%\n', THD_esperado_distorsionada);
fprintf('Diferencia: %.4f%%\n\n', abs(THD_distorsionada - THD_esperado_distorsionada));

%% ===================================================================
%% TAREA 3: CREAR TABLA COMPARATIVA CON LOS RESULTADOS
%% ===================================================================

fprintf('================================================================\n');
fprintf('TAREA 3: TABLA COMPARATIVA DE RESULTADOS\n');
fprintf('================================================================\n\n');

fprintf('%-25s %-20s %-20s %-20s\n', 'PARAMETRO', 'LINEAL', 'MODERADA', 'DISTORSIONADA');
fprintf('--------------------------------------------------------------------------------\n');
fprintf('%-25s %-20.2f %-20.2f %-20.2f\n', 'Fundamental (V)', mag_lineal(1), mag_moderada(1), mag_distorsionada(1));
fprintf('%-25s %-20.2f %-20.2f %-20.2f\n', '3er Armonico (V)', mag_lineal(3), mag_moderada(3), mag_distorsionada(3));
fprintf('%-25s %-20.2f %-20.2f %-20.2f\n', '5to Armonico (V)', mag_lineal(5), mag_moderada(5), mag_distorsionada(5));
fprintf('%-25s %-20.2f %-20.2f %-20.2f\n', '7mo Armonico (V)', mag_lineal(7), mag_moderada(7), mag_distorsionada(7));
fprintf('%-25s %-20.4f%% %-20.4f%% %-20.4f%%\n', 'THD Calculado', THD_lineal, THD_moderada, THD_distorsionada);
fprintf('%-25s %-20.1f%% %-20.1f%% %-20.1f%%\n', 'THD Esperado', THD_esperado_lineal, THD_esperado_moderada, THD_esperado_distorsionada);
fprintf('--------------------------------------------------------------------------------\n\n');

%% ===================================================================
%% TAREA 4: VISUALIZAR LOS ESPECTROS DE LAS TRES SENALES EN SUBPLOTS
%% ===================================================================

fprintf('================================================================\n');
fprintf('TAREA 4: VISUALIZACION DE ESPECTROS\n');
fprintf('================================================================\n');
fprintf('Generando graficas...\n\n');

figure('Position', [50 50 1600 1000]);
figure('Name', 'Comparacion de Cargas Electricas', 'NumberTitle', 'off');

% Subplot 1: Carga Lineal - Forma de onda
subplot(3,3,1);
t_4ciclos = 4/f0;
idx_4ciclos = t <= t_4ciclos;
plot(t(idx_4ciclos)*1000, senal_lineal(idx_4ciclos), 'b', 'LineWidth', 2);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 10);
ylabel('Voltaje (V)', 'FontSize', 10);
title('CARGA LINEAL - Forma de Onda', 'FontSize', 11, 'FontWeight', 'bold', 'Color', [0 0.5 0]);
xlim([0 t_4ciclos*1000]);

% Subplot 2: Carga Lineal - Espectro
subplot(3,3,2);
bar(1:num_armonicos, mag_lineal, 'FaceColor', [0 0.7 0.3], 'EdgeColor', 'black');
grid on;
xlabel('Numero de Armonico', 'FontSize', 10);
ylabel('Magnitud (V)', 'FontSize', 10);
title(sprintf('CARGA LINEAL - Espectro\nTHD = %.2f%%', THD_lineal), 'FontSize', 11, 'FontWeight', 'bold', 'Color', [0 0.5 0]);
xlim([0 num_armonicos+1]);
xticks(1:2:num_armonicos);

% Subplot 3: Carga Lineal - Detalle texto
subplot(3,3,3);
axis off;
text(0.1, 0.9, 'CARGA LINEAL (IDEAL)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', [0 0.5 0]);
text(0.1, 0.75, sprintf('THD: %.2f%%', THD_lineal), 'FontSize', 11);
text(0.1, 0.65, sprintf('V1: %.2f V', mag_lineal(1)), 'FontSize', 10);
text(0.1, 0.55, sprintf('V3: %.2f V', mag_lineal(3)), 'FontSize', 10);
text(0.1, 0.45, sprintf('V5: %.2f V', mag_lineal(5)), 'FontSize', 10);
text(0.1, 0.30, 'Caracteristicas:', 'FontSize', 10, 'FontWeight', 'bold');
text(0.1, 0.20, '- Sin armonicos', 'FontSize', 9);
text(0.1, 0.10, '- Calidad excelente', 'FontSize', 9);

% Subplot 4: Carga Moderada - Forma de onda
subplot(3,3,4);
plot(t(idx_4ciclos)*1000, senal_moderada(idx_4ciclos), 'b', 'LineWidth', 2);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 10);
ylabel('Voltaje (V)', 'FontSize', 10);
title('CARGA MODERADA - Forma de Onda', 'FontSize', 11, 'FontWeight', 'bold', 'Color', [0.8 0.5 0]);
xlim([0 t_4ciclos*1000]);

% Subplot 5: Carga Moderada - Espectro
subplot(3,3,5);
bar(1:num_armonicos, mag_moderada, 'FaceColor', [1 0.6 0.2], 'EdgeColor', 'black');
grid on;
xlabel('Numero de Armonico', 'FontSize', 10);
ylabel('Magnitud (V)', 'FontSize', 10);
title(sprintf('CARGA MODERADA - Espectro\nTHD = %.2f%%', THD_moderada), 'FontSize', 11, 'FontWeight', 'bold', 'Color', [0.8 0.5 0]);
xlim([0 num_armonicos+1]);
xticks(1:2:num_armonicos);

% Subplot 6: Carga Moderada - Detalle texto
subplot(3,3,6);
axis off;
text(0.1, 0.9, 'CARGA MODERADA', 'FontSize', 12, 'FontWeight', 'bold', 'Color', [0.8 0.5 0]);
text(0.1, 0.75, sprintf('THD: %.2f%%', THD_moderada), 'FontSize', 11);
text(0.1, 0.65, sprintf('V1: %.2f V', mag_moderada(1)), 'FontSize', 10);
text(0.1, 0.55, sprintf('V3: %.2f V (%.0f%%)', mag_moderada(3), mag_moderada(3)/mag_moderada(1)*100), 'FontSize', 10);
text(0.1, 0.45, sprintf('V5: %.2f V (%.0f%%)', mag_moderada(5), mag_moderada(5)/mag_moderada(1)*100), 'FontSize', 10);
text(0.1, 0.30, 'Caracteristicas:', 'FontSize', 10, 'FontWeight', 'bold');
text(0.1, 0.20, '- Distorsion leve', 'FontSize', 9);
text(0.1, 0.10, '- Aceptable (< 15%)', 'FontSize', 9);

% Subplot 7: Carga Distorsionada - Forma de onda
subplot(3,3,7);
plot(t(idx_4ciclos)*1000, senal_distorsionada(idx_4ciclos), 'b', 'LineWidth', 2);
grid on;
xlabel('Tiempo (ms)', 'FontSize', 10);
ylabel('Voltaje (V)', 'FontSize', 10);
title('CARGA DISTORSIONADA - Forma de Onda', 'FontSize', 11, 'FontWeight', 'bold', 'Color', [0.8 0 0]);
xlim([0 t_4ciclos*1000]);

% Subplot 8: Carga Distorsionada - Espectro
subplot(3,3,8);
bar(1:num_armonicos, mag_distorsionada, 'FaceColor', [0.9 0.2 0.2], 'EdgeColor', 'black');
grid on;
xlabel('Numero de Armonico', 'FontSize', 10);
ylabel('Magnitud (V)', 'FontSize', 10);
title(sprintf('CARGA DISTORSIONADA - Espectro\nTHD = %.2f%%', THD_distorsionada), 'FontSize', 11, 'FontWeight', 'bold', 'Color', [0.8 0 0]);
xlim([0 num_armonicos+1]);
xticks(1:2:num_armonicos);

% Subplot 9: Carga Distorsionada - Detalle texto
subplot(3,3,9);
axis off;
text(0.1, 0.9, 'CARGA DISTORSIONADA', 'FontSize', 12, 'FontWeight', 'bold', 'Color', [0.8 0 0]);
text(0.1, 0.75, sprintf('THD: %.2f%%', THD_distorsionada), 'FontSize', 11);
text(0.1, 0.65, sprintf('V1: %.2f V', mag_distorsionada(1)), 'FontSize', 10);
text(0.1, 0.55, sprintf('V3: %.2f V (%.0f%%)', mag_distorsionada(3), mag_distorsionada(3)/mag_distorsionada(1)*100), 'FontSize', 10);
text(0.1, 0.45, sprintf('V5: %.2f V (%.0f%%)', mag_distorsionada(5), mag_distorsionada(5)/mag_distorsionada(1)*100), 'FontSize', 10);
text(0.1, 0.35, sprintf('V7: %.2f V (%.0f%%)', mag_distorsionada(7), mag_distorsionada(7)/mag_distorsionada(1)*100), 'FontSize', 10);
text(0.1, 0.20, 'Caracteristicas:', 'FontSize', 10, 'FontWeight', 'bold');
text(0.1, 0.10, '- Alta distorsion (>30%)', 'FontSize', 9);
text(0.1, 0.00, '- REQUIERE FILTROS', 'FontSize', 9, 'Color', 'red', 'FontWeight', 'bold');

sgtitle('COMPARACION DE TRES TIPOS DE CARGAS ELECTRICAS', 'FontSize', 14, 'FontWeight', 'bold');

%% ===================================================================
%% TAREA 5: ANALIZAR SI ALGUNA CARGA SUPERA EL LIMITE DE 8%
%% ===================================================================

fprintf('================================================================\n');
fprintf('TAREA 5: ANALISIS DEL LIMITE NORMATIVO (8%%)\n');
fprintf('================================================================\n\n');

limite_normativo = 8;  % Segun IEEE 519

fprintf('Limite normativo segun IEEE 519: THD < %.0f%%\n\n', limite_normativo);

fprintf('Analisis de cumplimiento:\n');
fprintf('-------------------------\n');

% Carga Lineal
if THD_lineal < limite_normativo
    fprintf('CARGA LINEAL: THD = %.2f%% --> CUMPLE (%.2f%% por debajo)\n', ...
            THD_lineal, limite_normativo - THD_lineal);
else
    fprintf('CARGA LINEAL: THD = %.2f%% --> NO CUMPLE (%.2f%% por encima)\n', ...
            THD_lineal, THD_lineal - limite_normativo);
end

% Carga Moderada
if THD_moderada < limite_normativo
    fprintf('CARGA MODERADA: THD = %.2f%% --> CUMPLE (%.2f%% por debajo)\n', ...
            THD_moderada, limite_normativo - THD_moderada);
else
    fprintf('CARGA MODERADA: THD = %.2f%% --> NO CUMPLE (%.2f%% por encima)\n', ...
            THD_moderada, THD_moderada - limite_normativo);
end

% Carga Distorsionada
if THD_distorsionada < limite_normativo
    fprintf('CARGA DISTORSIONADA: THD = %.2f%% --> CUMPLE (%.2f%% por debajo)\n', ...
            THD_distorsionada, limite_normativo - THD_distorsionada);
else
    fprintf('CARGA DISTORSIONADA: THD = %.2f%% --> NO CUMPLE (%.2f%% por encima)\n', ...
            THD_distorsionada, THD_distorsionada - limite_normativo);
end

fprintf('\n================================================================\n');
fprintf('CONCLUSIONES:\n');
fprintf('================================================================\n');
fprintf('1. Carga Lineal: Ideal, sin necesidad de filtros\n');
fprintf('2. Carga Moderada: Supera limite, requiere atencion\n');
fprintf('3. Carga Distorsionada: Muy por encima, REQUIERE FILTROS URGENTE\n');
fprintf('\n*** ANALISIS COMPLETADO EXITOSAMENTE ***\n');
fprintf('================================================================\n');

%% ===================================================================
%% FUNCION: ANALIZAR ARMONICOS
%% ===================================================================
function [freq_armonicos, mag_armonicos, THD] = analizar_armonicos(senal, fs, f0, num_armonicos)
    % Calcular FFT
    N = length(senal);
    Y = fft(senal);
    P2 = abs(Y/N);
    P1 = P2(1:N/2+1);
    P1(2:end-1) = 2*P1(2:end-1);
    f = fs*(0:(N/2))/N;
    
    % Extraer magnitudes de armonicos
    freq_armonicos = zeros(1, num_armonicos);
    mag_armonicos = zeros(1, num_armonicos);
    
    for n = 1:num_armonicos
        freq_armonicos(n) = n * f0;
        [~, idx] = min(abs(f - freq_armonicos(n)));
        mag_armonicos(n) = P1(idx);
    end
    
    % Calcular THD
    suma_cuadrados = sum(mag_armonicos(2:num_armonicos).^2);
    THD = (sqrt(suma_cuadrados) / mag_armonicos(1)) * 100;
end